library(testthat)
test_check('EcoSimR')
